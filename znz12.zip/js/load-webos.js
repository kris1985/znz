// JavaScript Document
$(function(){
	//alert(2);
})
loadBox = function(){
	var _box = "";
	
	return lb = {
		init:function(){
			lb.create();
		},
		create:function(){
		
		}
	}
}();